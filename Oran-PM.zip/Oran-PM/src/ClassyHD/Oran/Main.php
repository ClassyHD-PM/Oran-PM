<?php

namespace ClassyHD\Oran;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\world\sound\PopSound;

use jojoe77777\FormAPI\CustomForm;

class Main extends PluginBase implements Listener {

    private array $permissionChances = [];
    private int $defaultChance = 5;

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->permissionChances = $this->getConfig()->get("permissions", []);
        $this->defaultChance = $this->getConfig()->get("default-chance", 5);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function getDropChance(Player $player): int {
        foreach (["ultra.perm", "vip.perm", "oyuncu.perm"] as $perm) {
            if ($player->hasPermission($perm)) {
                return $this->permissionChances[$perm] ?? $this->defaultChance;
            }
        }
        return $this->defaultChance;
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        $block = $event->getBlock();
        $player = $event->getPlayer();

        if ($block->getTypeId() === VanillaBlocks::STONE()->getTypeId() ||
            $block->getTypeId() === VanillaBlocks::COBBLESTONE()->getTypeId()) {

            $chance = $this->getDropChance($player);

            if (mt_rand(1, 100) <= $chance) {
                $items = [
                    VanillaItems::DIAMOND(),
                    VanillaItems::EMERALD(),
                    VanillaItems::COAL(),
                    VanillaItems::IRON_INGOT(),
                    VanillaItems::GOLD_INGOT(),
                    VanillaItems::NETHERITE_SCRAP()
                ];
                $randomItem = $items[array_rand($items)];
                $player->getInventory()->addItem($randomItem);
                $player->sendPopup("§f[" . $randomItem->getName() . "] §aDüşürdün!");
                $player->getWorld()->addSound($block->getPosition(), new PopSound());
            }
        }
    }

    public function sendOranInputForm(Player $player): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) return;

            $sliderValue = (int)$data[0];

            $permMap = [
                1 => "oyuncu.perm",
                3 => "vip.perm",
                5 => "ultra.perm"
            ];

            $perm = $permMap[$sliderValue] ?? null;

            if ($perm === null || !$player->hasPermission($perm)) {
                $player->sendMessage("§cBu oranı ayarlamak için gerekli iznin yok!");
                return;
            }

            $chanceValue = match ($sliderValue) {
                1 => 10,
                3 => 30,
                5 => 50,
                default => 0,
            };

            $config = $this->getConfig();
            $config->set("permissions." . $perm, $chanceValue);
            $config->save();

            $this->permissionChances = $config->get("permissions", []);
            $player->sendMessage("§aOranın başarıyla §f%$chanceValue §aolarak ayarlandı!");
        });

        $form->setTitle("Oran Ayarla");
        $form->addSlider("Oranını Seç", 1, 5, 2, 1);
        $player->sendForm($form);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "oran" && $sender instanceof Player) {
            if (!$sender->hasPermission("oran.command.oran")) {
                $sender->sendMessage("§cBu komutu kullanmak için iznin yok!");
                return true;
            }
            $this->sendOranInputForm($sender);
            return true;
        }
        return false;
    }
}